document.addEventListener('DOMContentLoaded', function () {
  // Get references to the tab buttons
  const quickTabButton = document.getElementById('quickTabButton');
  const detailedTabButton = document.getElementById('detailedTabButton');
  const publicTransportButton = document.getElementById('publicTransportButton');
  const privateTransportButton = document.getElementById('privateTransportButton');

  // Get references to the tab content elements
  const publicTransportQuick = document.getElementById('publicTransportQuick');
  const publicTransportDetailed = document.getElementById('publicTransportDetailed');
  const privateTransportQuick = document.getElementById('privateTransportQuick');
  const privateTransportDetailed = document.getElementById('privateTransportDetailed');

  // Function to hide all tab content
  function hideAllTabContent() {
      publicTransportQuick.style.display = 'none';
      publicTransportDetailed.style.display = 'none';
      privateTransportQuick.style.display = 'none';
      privateTransportDetailed.style.display = 'none';
  }

  // Function to activate the specified tab and mode
  function activateTab(tabName, mode) {
      const transportButtons = document.querySelectorAll('.transport');
      const modeButtons = document.querySelectorAll('.tablinks');

      // Remove 'active' class from all buttons
      transportButtons.forEach(button => button.classList.remove('active'));
      modeButtons.forEach(button => button.classList.remove('active'));

      // Add 'active' class to the appropriate buttons
      if (tabName === 'publicTransport') {
          publicTransportButton.classList.add('active');
      } else {
          privateTransportButton.classList.add('active');
      }

      if (mode === 'quick') {
          quickTabButton.classList.add('active');
      } else {
          detailedTabButton.classList.add('active');
      }

      // Hide all tab content
      hideAllTabContent();

      // Show the selected tab and mode content
      if (tabName === 'publicTransport') {
          if (mode === 'quick') {
              publicTransportQuick.style.display = 'block';
          } else {
              publicTransportDetailed.style.display = 'block';
          }
      } else {
          if (mode === 'quick') {
              privateTransportQuick.style.display = 'block';
          } else {
              privateTransportDetailed.style.display = 'block';
          }
      }
  }

  // Function to show the specified tab with the quick content initially
  function showTab(tabName) {
      activateTab(tabName, 'quick');
      quickTabButton.addEventListener('click', () => activateTab(tabName, 'quick'));
      detailedTabButton.addEventListener('click', () => activateTab(tabName, 'detailed'));
  }

  // Event listeners for the transport buttons
  publicTransportButton.addEventListener('click', () => showTab('publicTransport'));
  privateTransportButton.addEventListener('click', () => showTab('privateTransport'));

  // Initial load: display the Public Transport tab with Quick content
  showTab('publicTransport');
});
