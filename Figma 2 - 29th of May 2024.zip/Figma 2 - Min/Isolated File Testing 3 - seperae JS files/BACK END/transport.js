// Function to initialize the page with the Public Transport tab and Quick content displayed
document.addEventListener('DOMContentLoaded', function () {
    showTabContent('publicTransportQuick');
    highlightButtons('publicTransportButton', 'quickTabButton');

    // Event listeners for transport buttons
    document.getElementById('publicTransportButton').addEventListener('click', function () {
        showTabContent('publicTransportQuick');
        highlightButtons('publicTransportButton', 'quickTabButton');
    });
    document.getElementById('privateTransportButton').addEventListener('click', function () {
        showTabContent('privateTransportQuick');
        highlightButtons('privateTransportButton', 'quickTabButton');
    });

    // Event listeners for mode buttons
    document.getElementById('quickTabButton').addEventListener('click', function () {
        var activeTransportButton = document.querySelector('.transport.active');
        if (activeTransportButton.id === 'publicTransportButton') {
            showTabContent('publicTransportQuick');
        } else {
            showTabContent('privateTransportQuick');
        }
        highlightButtons(activeTransportButton.id, 'quickTabButton');
    });
    document.getElementById('detailedTabButton').addEventListener('click', function () {
        var activeTransportButton = document.querySelector('.transport.active');
        if (activeTransportButton.id === 'publicTransportButton') {
            showTabContent('publicTransportDetailed');
        } else {
            showTabContent('privateTransportDetailed');
        }
        highlightButtons(activeTransportButton.id, 'detailedTabButton');
    });

    // Event listener for dropdown selection in detailed mode
    document.getElementById('detailedPublicTransportOptions').addEventListener('change', function () {
        generateTableRow(this.value);
    });

    // Event listener for adding a new item in the detailed table
    document.getElementById('addItemButton').addEventListener('click', function () {
        var dropdown = document.getElementById('detailedPublicTransportOptions');
        generateTableRow(dropdown.value);
    });
});

// Function to show the selected tab content
function showTabContent(contentId) {
    var tabContents = document.getElementsByClassName('tabcontent');
    for (var i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = 'none';
    }
    document.getElementById(contentId).style.display = 'block';
}

// Function to highlight the selected buttons
function highlightButtons(transportButtonId, modeButtonId) {
    var transportButtons = document.getElementsByClassName('transport');
    for (var i = 0; i < transportButtons.length; i++) {
        transportButtons[i].classList.remove('active');
    }
    var modeButtons = document.getElementsByClassName('tablinks');
    for (var i = 0; i < modeButtons.length; i++) {
        modeButtons[i].classList.remove('active');
    }
    document.getElementById(transportButtonId).classList.add('active');
    document.getElementById(modeButtonId).classList.add('active');
}

// Function to generate a table row based on the dropdown selection
function generateTableRow(type) {
    if (!type) return; // Prevent adding a row if no type is selected

    var table = document.getElementById('publicTransportTable').getElementsByTagName('tbody')[0];
    var row = table.insertRow();

    // Add cells to the row
    var ghgCell = row.insertCell(0);
    var idCell = row.insertCell(1);
    var kmsCell = row.insertCell(2);
    var typeCell = row.insertCell(3);
    var tripsCell = row.insertCell(4);
    var distanceCell = row.insertCell(5);
    var occupancyCell = row.insertCell(6);
    var actionCell = row.insertCell(7);

    // Set cell values
    ghgCell.innerHTML = '0';
    idCell.innerHTML = '0';
    kmsCell.innerHTML = '0';
    typeCell.innerHTML = type;
    tripsCell.innerHTML = '0';
    distanceCell.innerHTML = '0';
    occupancyCell.innerHTML = '0';

    // Add delete button to the action cell
    var deleteButton = document.createElement('button');
    deleteButton.innerHTML = 'Delete';
    deleteButton.addEventListener('click', function () {
        deleteTableRow(this);
    });
    actionCell.appendChild(deleteButton);
}

// Function to delete a table row
function deleteTableRow(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}
