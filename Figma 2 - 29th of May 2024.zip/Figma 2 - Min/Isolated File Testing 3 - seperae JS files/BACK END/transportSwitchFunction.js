document.addEventListener('DOMContentLoaded', function() {
    const privateTranTabButton = document.getElementById('privateTranTabButton');
    const publicTranTabButton = document.getElementById('publicTranTabButton');
    const quickTabButton = document.getElementById('quickTabButton');
    const detailedTabButton = document.getElementById('detailedTabButton');

    const privateQuick = document.getElementById('privateQuick');
    const privateDetailed = document.getElementById('privateDetailed');
    const publicQuick = document.getElementById('publicQuick');
    const publicDetailed = document.getElementById('publicDetailed');

    function hideAllContent() {
        privateQuick.style.display = 'none';
        privateDetailed.style.display = 'none';
        publicQuick.style.display = 'none';
        publicDetailed.style.display = 'none';
    }

    function updateContent() {
        hideAllContent();
        if (currentPage === 'private' && currentTab === 'quick') {
            privateQuick.style.display = 'block';
        } else if (currentPage === 'private' && currentTab === 'detailed') {
            privateDetailed.style.display = 'block';
        } else if (currentPage === 'public' && currentTab === 'quick') {
            publicQuick.style.display = 'block';
        } else if (currentPage === 'public' && currentTab === 'detailed') {
            publicDetailed.style.display = 'block';
        }
    }

    function setActivePage(button) {
        privateTranTabButton.classList.remove('active');
        publicTranTabButton.classList.remove('active');
        button.classList.add('active');
    }

    function setActiveTab(button) {
        quickTabButton.classList.remove('active');
        detailedTabButton.classList.remove('active');
        button.classList.add('active');
    }

    privateTranTabButton.addEventListener('click', function() {
        currentPage = 'private';
        currentTab = 'quick';
        setActivePage(privateTranTabButton);
        setActiveTab(quickTabButton);
        updateContent();
    });

    publicTranTabButton.addEventListener('click', function() {
        currentPage = 'public';
        currentTab = 'quick';
        setActivePage(publicTranTabButton);
        setActiveTab(quickTabButton);
        updateContent();
    });

    quickTabButton.addEventListener('click', function() {
        currentTab = 'quick';
        setActiveTab(quickTabButton);
        updateContent();
    });

    detailedTabButton.addEventListener('click', function() {
        currentTab = 'detailed';
        setActiveTab(detailedTabButton);
        updateContent();
    });

    // Show public quick content by default
    setActivePage(publicTranTabButton);
    setActiveTab(quickTabButton);
    updateContent();
});
