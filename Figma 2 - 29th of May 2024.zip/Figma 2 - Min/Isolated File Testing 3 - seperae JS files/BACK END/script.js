

// Function to calculate total emissions
function calculateEmissions() {
    // Get the values from the QUICK dropdowns
    const value1 = parseInt(document.getElementById('dropdown1').value);
    const value2 = parseInt(document.getElementById('dropdown2').value);
    const value3 = parseInt(document.getElementById('dropdown3').value);
    const value4 = parseInt(document.getElementById('dropdown4').value);

    // Calculate total emissions
    const publicTransportQuickEmmissions = value1 + value2 + value3 +value4;
    const publicTransportDetailedEmissions = 0;
    const totalEmissions = publicTransportQuickEmmissions + publicTransportDetailedEmissions;

    // Update the total emissions element
    document.getElementById('totalAirGHG').innerText = totalEmissions;
    document.getElementById('totalGHG').innerText = totalEmissions;

    // Update the bar chart width
    updateBarChart(totalEmissions);

    // Return the total emissions (in case you need to use it elsewhere)
    return totalEmissions;
}

// Function to update the bar chart based on total emissions
function updateBarChart(emissions) {
    // Assuming the maximum emissions value is 100 for the purpose of the bar width calculation
    const maxEmissions = 10000;
    const barWidth = (emissions / maxEmissions) * 100; // Calculate the width as a percentage

    // Set the width of the bar element
    document.getElementById('ghg1bar').style.width = barWidth + '%';
}

// Add event listeners to the dropdowns
// PUBLIC TRANSPORT - QUICK 
document.getElementById('dropdown1').addEventListener('change', calculateEmissions);
document.getElementById('dropdown2').addEventListener('change', calculateEmissions);
document.getElementById('dropdown3').addEventListener('change', calculateEmissions);
document.getElementById('dropdown4').addEventListener('change', calculateEmissions);
// PUBLIC TRANSPORT - DETAILED
document.getElementById('dropdown5').addEventListener('change', calculateEmissions);


// Initial calculation
calculateEmissions();
