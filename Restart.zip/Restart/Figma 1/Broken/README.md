# Carbon-Choice-Calculator
Development of a web-based calculator for households to explore the activities involved in their carbon emissions so they can set priorities for cutting their emissions from household energy use, purchasing of food and everyday items, land-based and air travel through selection of appliances, services and food, behavioural change and building design.
