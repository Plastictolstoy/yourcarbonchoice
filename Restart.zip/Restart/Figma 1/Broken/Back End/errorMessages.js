/*
Console log error messages: AirTravelMoudle 
*/

function validateInput(inputValue) {
    if (isNaN(inputValue) || inputValue < 0) {
      return false; // Return false for invalid input
    }
    return true; // Return true for valid input
  }
  

//  tripsInput field
tripsInput.addEventListener('input', function () {
    const inputValue = parseInt(tripsInput.value);
    if (!validateInput(inputValue)) {
      console.error('Invalid input for trips: Please enter a vaild or non-negative number.');
      tripsInput.value = '';
    } else {
      // Proceed with the calculation
      updateTableRowValues();
    }
  });

  // userSpecifydistanceInput field
userSpecifydistanceInput.addEventListener('input', function () {
    const inputValue = parseInt(userSpecifydistanceInput.value);
    if (!validateInput(inputValue)) {
      console.error('Invalid input for user-specified distance: Please enter a vaild or non-negative number.');
      // Clear the input field:
      userSpecifydistanceInput.value = '';
    } else {
      // Proceed with the calculation
      updateTableRowValues();
    }
  });
    // userSpecifyseatTypeInput field
  userSpecifyseatTypeInput.addEventListener('input', function () {
    const inputValue = parseInt(userSpecifyseatTypeInput.value);
    if (!validateInput(inputValue)) {
      console.error('Invalid input for user-specified seat type: Please enter a vaild or non-negative number.');
      // Clear the input field:
      userSpecifyseatTypeInput.value = '';
    } else {
      // Proceed with the calculation
      updateTableRowValues();
    }
  });
    // userSpecifyCruiseghInput field
    userSpecifyCruiseghInput.addEventListener('input', function () {
    const inputValue = parseInt(userSpecifyCruiseghInput.value);
    if (!validateInput(inputValue)) {
      console.error('Invalid input for user-specified aircraft type: Please enter a vaild or non-negative number.');
      // Clear the input field:
      userSpecifyCruiseghInput.value = '';
    } else {
      // Proceed with the calculation
      updateTableRowValues();
    }
  });

    // userSpecifyLTOghInput field
    userSpecifyLTOghInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyLTOghInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified landing emissons: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyLTOghInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });

    // userSpecifyStopOverInput field
    userSpecifyStopOverInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyStopOverInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified Stop Over: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyStopOverInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });

    // userSpecifyWarmingFactorInput field
    userSpecifyWarmingFactorInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyWarmingFactorInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified Warming Factor: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyWarmingFactorInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });

    // userSpecifyOccupancyInput field
    userSpecifyOccupancyInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyOccupancyInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified Occupancy: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyOccupancyInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });

    // userSpecifyLTODistInput field
    userSpecifyLTODistInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyLTODistInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified landing distance: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyLTODistInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });

    // userSpecifyLoadingFactorInput field
    userSpecifyLoadingFactorInput.addEventListener('input', function () {
        const inputValue = parseInt(userSpecifyLoadingFactorInput.value);
        if (!validateInput(inputValue)) {
          console.error('Invalid input for user-specified loading factor: Please enter a vaild or non-negative number.');
          // Clear the input field:
          userSpecifyLoadingFactorInput.value = '';
        } else {
          // Proceed with the calculation
          updateTableRowValues();
        }
      });
